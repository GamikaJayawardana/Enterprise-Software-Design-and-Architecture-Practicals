package com.example.RESTfulDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResTfulDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

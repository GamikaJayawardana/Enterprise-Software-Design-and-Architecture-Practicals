package com.example.RESTfulDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResTfulDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResTfulDemoApplication.class, args);
	}

}
